from app.commands import Command


class websysCommand(Command):
    def execute(self):
        print("You are attending WebSystems Development class by Prof. Keith Williams")
from app.commands import Command


class amazeCommand(Command):
    def execute(self):
        print("Have an Amazing Day ahead!!")